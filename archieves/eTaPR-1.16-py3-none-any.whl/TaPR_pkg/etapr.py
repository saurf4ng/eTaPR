from TaPR_pkg import tapr
import math
import argparse
from TaPR_pkg.DataManage import File_IO, Time_Plot
import numpy as np

class eTaPR(tapr.TaPR):
    def __init__(self, rho, pi, delta):
        super(eTaPR, self).__init__(0.0, delta)
        self._predictions_weight = []
        self._predictions_total_weight = 0.0
        self._prune_predictions = []

        self._rho = rho
        self._pi = pi

        self._score_matrix_por = 0
        self._score_matrix_det = 0
        self._max_anomaly_score = []
        self._max_prediction_score = []

    #load data -> build the score matrix -> do pruning
    def set(self, anomalies: list, predictions: list) -> None:
        #loading data
        self.set_anomalies(anomalies)
        self.set_predictions(predictions)

        #computing weights
        for a_prediction in self._predictions:
            first, last = a_prediction.get_time()
            temp_weight = math.sqrt(last-first+1)
            self._predictions_weight.append(temp_weight)
            self._predictions_total_weight += temp_weight

        #building the score matrix
        self._score_matrix_det = np.zeros((self.get_n_anomalies(), self.get_n_predictions()))
        for anomaly_id in range(self.get_n_anomalies()):
            for prediction_id in range(self.get_n_predictions()):
                self._score_matrix_det[anomaly_id, prediction_id] = \
                    float(self._overlap_and_subsequent_score(self._anomalies[anomaly_id], self._ambiguous_inst[anomaly_id], self._predictions[prediction_id]))
        self._score_matrix_por = self._score_matrix_det.copy()

        #computing the maximum scores for each anomaly or prediction
        for an_anomaly in self._anomalies:
            start, end = an_anomaly.get_time()
            self._max_anomaly_score.append(float(self._sum_of_func(start, end, start, end, self._uniform_func)))
        for a_prediction in self._predictions:
            self._max_prediction_score.append(a_prediction.get_len())

        #pruning
        self._pruning()

    def set_w_early_stop(self, anomalies: list, predictions: list, tap_threshold: float, tar_threshold: float, alpha: float) -> bool:
        #loading data
        self.set_anomalies(anomalies)
        self.set_predictions(predictions)

        #computing weights
        for a_prediction in self._predictions:
            first, last = a_prediction.get_time()
            temp_weight = math.sqrt(last-first+1)
            self._predictions_weight.append(temp_weight)
            self._predictions_total_weight += temp_weight

        #building the score matrix
        self._score_matrix_det = np.zeros((self.get_n_anomalies(), self.get_n_predictions()))
        for anomaly_id in range(self.get_n_anomalies()):
            for prediction_id in range(self.get_n_predictions()):
                self._score_matrix_det[anomaly_id, prediction_id] = \
                    float(self._overlap_and_subsequent_score(self._anomalies[anomaly_id], self._ambiguous_inst[anomaly_id], self._predictions[prediction_id]))
        self._score_matrix_por = self._score_matrix_det.copy()

        #computing the maximum scores for each anomaly or prediction
        for an_anomaly in self._anomalies:
            start, end = an_anomaly.get_time()
            self._max_anomaly_score.append(float(self._sum_of_func(start, end, start, end, self._uniform_func)))
        for a_prediction in self._predictions:
            self._max_prediction_score.append(a_prediction.get_len())

        tap_thd = (tap_threshold - (1-alpha)*self.TaP_p())/alpha
        tar_thd = (tar_threshold - (1-alpha)*self.TaR_p())/alpha

        #pruning
        while True:
            tars = self._score_matrix_det.sum(axis=1) / self._max_anomaly_score
            elem_anomaly_ids = set(np.where(tars < self._rho)[0]) - set(np.where(tars == 0.0)[0])
            for id in elem_anomaly_ids:
                self._score_matrix_det[id] = np.zeros(self.get_n_predictions())
            taps = self._score_matrix_det.sum(axis=0) / self._max_prediction_score
            elem_prediction_ids = set(np.where(taps < self._pi)[0]) - set(np.where(taps == 0.0)[0])
            for id in elem_prediction_ids:
                self._score_matrix_det[:, id] = np.zeros(self.get_n_anomalies())


            if len(elem_anomaly_ids) == 0 and len(elem_prediction_ids) == 0:
                return True
            elif self.TaP_d()[0] < tap_thd or self.TaR_d()[0] < tar_thd:
                return False

    def _pruning(self):
        while True:
            tars = self._score_matrix_det.sum(axis=1)/self._max_anomaly_score
            elem_anomaly_ids = set(np.where(tars<self._rho)[0]) - set(np.where(tars==0.0)[0])
            for id in elem_anomaly_ids:
                self._score_matrix_det[id] = np.zeros(self.get_n_predictions())
            taps = self._score_matrix_det.sum(axis=0)/self._max_prediction_score
            elem_prediction_ids = set(np.where(taps<self._pi)[0]) - set(np.where(taps==0.0)[0])
            for id in elem_prediction_ids:
                self._score_matrix_det[:, id] = np.zeros(self.get_n_anomalies())

            if len(elem_anomaly_ids) == 0 and len(elem_prediction_ids) == 0:
                break

    def TaR_d(self) -> float and list:
        if self.get_n_anomalies() == 0.0 or self.get_n_predictions() == 0.0:
            return 0.0, []

        scores = self._score_matrix_det.sum(axis=1)/self._max_anomaly_score
        scores = np.where(scores>1.0, 1.0, scores)
        detected_id_list = np.where(scores >= self._rho)[0]
        return len(detected_id_list)/self.get_n_anomalies(), detected_id_list

    def TaR_p(self) -> float:
        if self.get_n_anomalies() == 0.0 or self.get_n_predictions() == 0.0:
            return 0.0

        scores = self._score_matrix_por.sum(axis=1) / self._max_anomaly_score
        scores = np.where(scores > 1.0, 1.0, scores)
        return scores.mean()

    def TaP_d(self) -> float and list:
        if self.get_n_anomalies() == 0.0 or self.get_n_predictions() == 0.0:
            return 0.0, []

        scores = self._score_matrix_det.sum(axis=0) / self._max_prediction_score
        correct_id_list = np.where(scores >= self._pi)[0]
        tapd = 0.0
        for correct_id in correct_id_list:
            tapd += self._predictions_weight[correct_id]
        tapd /= float(self._predictions_total_weight)
        return tapd, correct_id_list

    def TaP_p(self) -> float:
        if self.get_n_anomalies() == 0.0 or self.get_n_predictions() == 0.0:
            return 0.0

        scores = self._score_matrix_por.sum(axis=0) / self._max_prediction_score
        final_score = 0.0
        for i in range(len(scores)):
            final_score += float(self._predictions_weight[i]) * scores[i]
        final_score /= float(self._predictions_total_weight)
        return final_score


def evaluate_w_ranges(anomalies: list, predictions: list, alpha: float, rho: float, pi: float, delta: int) -> dict:
    ev = eTaPR(rho, pi, delta)
    ev.set(anomalies, predictions)

    tard_value, detected_id_list = ev.TaR_d()
    tarp_value = ev.TaR_p()

    tapd_value, correct_id_list = ev.TaP_d()
    tapp_value = ev.TaP_p()

    result = {}
    tar_value = alpha * tard_value + (1 - alpha) * tarp_value
    result['TaR'] = tar_value
    result['TaRd'] = tard_value
    result['TaRp'] = tarp_value

    tap_value = alpha * tapd_value + (1 - alpha) * tapp_value
    result['TaP'] = tap_value
    result['TaPd'] = tapd_value
    result['TaPp'] = tapp_value

    detected_anomalies = []
    for id in detected_id_list:
        detected_anomalies.append(anomalies[id])

    correct_predictions = []
    for id in correct_id_list:
        correct_predictions.append(predictions[id])

    result['Detected_Anomalies'] = detected_anomalies
    result['Correct_Predictions'] = correct_predictions

    if tar_value + tap_value == 0:
        result['f1'] = 0.0
    else:
        result['f1'] = (2 * tar_value * tap_value) / (tar_value + tap_value)

    false_alarm = 0
    false_alarm_cnt = 0
    for id in range(len(predictions)):
        if id not in correct_id_list:
            false_alarm += predictions[id].get_len()
            false_alarm_cnt += 1
    result['False Alarm'] = false_alarm
    result['N False Alarm'] = false_alarm_cnt

    return result


def evaluate_w_streams(anomalies: list, predictions: list) -> dict:
    anomalous_ranges = File_IO.load_stream_2_range(anomalies, 0, 1, True)
    predicted_ranges = File_IO.load_stream_2_range(predictions, 0, 1, True)

    return evaluate_w_ranges(anomalies =anomalous_ranges,
                   predictions =predicted_ranges,
                   alpha=0.5,
                   rho=0.1,
                   pi=0.7,
                   delta=180)


def evaluate_w_files(anomaly_file: str, prediction_file: str, file_type: str, alpha: float, rho: float, pi: float, delta: int) -> dict:
    anomalies = File_IO.load_file(anomaly_file, file_type)
    predictions = File_IO.load_file(prediction_file, file_type)

    return evaluate_w_ranges(anomalies, predictions, alpha, rho, pi, delta)


def evaluate_w_early_stop(anomalies: list, predictions: list, tap_threshold: float, tar_threshold: float) -> dict:
    anomalous_ranges = File_IO.load_stream_2_range(anomalies, 0, 1, True)
    predicted_ranges = File_IO.load_stream_2_range(predictions, 0, 1, True)
    alpha = 0.5

    ev = eTaPR(rho=0.1, pi=0.7, delta=180)
    if ev.set_w_early_stop(anomalous_ranges, predicted_ranges, tap_threshold, tar_threshold, alpha):
        tard_value, detected_id_list = ev.TaR_d()
        tarp_value = ev.TaR_p()

        tapd_value, correct_id_list = ev.TaP_d()
        tapp_value = ev.TaP_p()
    else:
        tard_value = -1.0
        tarp_value = -1.0
        tapd_value = -1.0
        tapp_value = -1.0
        detected_id_list = []
        correct_id_list = []

    result = {}
    tar_value = alpha * tard_value + (1 - alpha) * tarp_value
    result['TaR'] = tar_value
    result['TaRd'] = tard_value
    result['TaRp'] = tarp_value

    tap_value = alpha * tapd_value + (1 - alpha) * tapp_value
    result['TaP'] = tap_value
    result['TaPd'] = tapd_value
    result['TaPp'] = tapp_value

    detected_anomalies = []
    for id in detected_id_list:
        detected_anomalies.append(anomalies[id])
    correct_predictions = []
    for id in correct_id_list:
        correct_predictions.append(predictions[id])

    result['Detected_Anomalies'] = detected_anomalies

    if tar_value + tap_value == 0:
        result['f1'] = 0.0
    else:
        result['f1'] = (2 * tar_value * tap_value) / (tar_value + tap_value)

    result['Detected_Anomalies'] = detected_anomalies
    result['Correct_Predictions'] = correct_predictions

    if tar_value + tap_value == 0:
        result['f1'] = 0.0
    else:
        result['f1'] = (2 * tar_value * tap_value) / (tar_value + tap_value)

    false_alarm = 0
    false_alarm_cnt = 0
    for id in range(len(predictions)):
        if id not in correct_id_list:
            false_alarm += predictions[id].get_len()
            false_alarm_cnt += 1
    result['False Alarm'] = false_alarm
    result['N False Alarm'] = false_alarm_cnt

    return result


def print_results(result: dict, verbose: bool) -> None:
    print('\n[TaR]:', "%0.5f" % result['TaR'])
    print("\t* Detection score:", "%0.5f" % result['TaRd'])
    print("\t* Portion score:", "%0.5f" % result['TaRp'])
    if verbose:
        buf = '\t\tdetected anomalies: '
        if len(result['Detected_Anomalies']) == 0:
            buf += "None  "
        else:
            for value in result['Detected_Anomalies']:
                buf += value.get_name() + '(' + str(value.get_time()[0]) + ':' + str(value.get_time()[1]) + '), '
        print(buf[:-2])


    print('\n[TaP]:', "%0.5f" % result['TaP'])
    print("\t* Detection score:", "%0.5f" % result['TaPd'])
    print("\t* Portion score:", "%0.5f" % result['TaPp'])
    if verbose:
        buf = '\t\tcorrect predictions: '
        if len(result['Correct_Predictions']) == 0:
            buf += "None  "
        else:
            for value in result['Correct_Predictions']:
                buf += value.get_name() + '(' + str(value.get_time()[0]) + ':' + str(value.get_time()[1]) + '), '
        print(buf[:-2])


def draw_graph(anomalies: list, predictions: list, graph_dst: str) -> None:
    assert (graph_dst == 'screen' or graph_dst == 'file' or graph_dst == 'none' or graph_dst == 'all')
    if graph_dst == 'screen' or graph_dst == 'file' or graph_dst == 'all':
        Time_Plot.draw_graphs(anomalies, predictions, graph_dst)


if __name__ == '__main__':
    argument_parser = argparse.ArgumentParser()
    argument_parser.add_argument("--anomalies", help="anomaly file name (ground truth)", required=True)
    argument_parser.add_argument("--predictions", help="prediction file name", required=True)
    argument_parser.add_argument("--filetype", help="choose the file type between range and stream", required=True)
    argument_parser.add_argument("--graph", help="show graph of results")

    argument_parser.add_argument("--verbose", help="show detail results", action='store_true')
    argument_parser.add_argument("--rho", help="set parameter rho")
    argument_parser.add_argument("--pi", help="set parameter pi")
    argument_parser.add_argument("--alpha", help="set parameter alpha")
    argument_parser.add_argument("--delta", help="set parameter delta")
    arguments = argument_parser.parse_args()

    arguments = argument_parser.parse_args()
    rho, pi, alpha, delta, graph = 0.1, 0.5, 0.8, 600, 'none'  #default values
    if arguments.rho is not None:
        rho = float(arguments.rho)
    if arguments.pi is not None:
        pi = float(arguments.pi)
    if arguments.alpha is not None:
        alpha = float(arguments.alpha)
    if arguments.delta is not None:
        delta = int(arguments.delta)
    if arguments.graph is not None:
        graph = arguments.graph

    assert(0.0 <= rho <= 1.0)
    assert(0.0 <= pi <= 1.0)
    assert(0.0 <= alpha <= 1.0)
    assert(isinstance(delta, int))
    assert(graph == 'screen' or graph == 'file' or graph == 'none' or graph == 'all')

    anomalies = File_IO.load_file(arguments.anomalies, arguments.filetype)
    predictions = File_IO.load_file(arguments.predictions, arguments.filetype)
    results = evaluate_w_ranges(anomalies, predictions, alpha, rho, pi, delta)

    print_results(results, arguments.verbose)
    draw_graph(anomalies, predictions, graph)

