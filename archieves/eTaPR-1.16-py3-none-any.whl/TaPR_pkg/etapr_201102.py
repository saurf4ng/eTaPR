from TaPR_pkg import tapr
import math
import argparse
import copy
from TaPR_pkg.DataManage import File_IO, Time_Plot
import decimal

class eTaPR(tapr.TaPR):
    def __init__(self, rho, pi, delta):
        super(eTaPR, self).__init__(0.0, delta)
        self._org_predictions_weight = []
        self._org_predictions_total_weight = decimal.Decimal(0.0)
        self._prune_predictions = []

        self._rho = rho
        self._pi = pi

    def pruning(self):
        incorrect_prediction_ids = []
        incorrect_prediction_ids = self.pruning_an_iteration(incorrect_prediction_ids)

        for a_prediction in self._predictions:
            first, last = a_prediction.get_time()
            temp_weight = decimal.Decimal(math.sqrt(last-first+1))
            self._org_predictions_weight.append(temp_weight)
            self._org_predictions_total_weight += (temp_weight)

        self._prune_predictions = copy.deepcopy(self._predictions)
        for id in incorrect_prediction_ids:
            self._prune_predictions[id].set_time(-2, -1)


    def pruning_an_iteration(self, incorrect_prediction_ids: list) -> None:
        local_predictions = []
        local_prediction_ids = []
        for id in range(self.get_n_predictions()):
            if id not in incorrect_prediction_ids:
                local_predictions.append(self._predictions[id])
                local_prediction_ids.append(id)

        _, detected_anomalies_id = self._TaR_d(self._anomalies, self._ambiguous_inst, local_predictions, self._rho)

        local_anomalies = []
        local_ambiguouses = []
        for id in range(self.get_n_anomalies()):
            if id in detected_anomalies_id:
                local_anomalies.append(self._anomalies[id])
                local_ambiguouses.append(self._ambiguous_inst[id])

        _, correct_prediction_ids = self._TaP_d(local_anomalies, local_ambiguouses, local_predictions, self._pi)

        if len(local_predictions) != len(correct_prediction_ids):
            for id in range(len(local_predictions)):
                if id not in correct_prediction_ids:
                    incorrect_prediction_ids.append(local_prediction_ids[id])
            incorrect_prediction_ids.sort()

            return self.pruning_an_iteration(incorrect_prediction_ids)
        else:
            return incorrect_prediction_ids


    def TaR_d(self) -> float and list:
        score, detected_id_list = self._TaR_d(self._anomalies, self._ambiguous_inst, self._prune_predictions, self._rho)
        return score, self._ids_2_objects(detected_id_list, self._anomalies)

    def TaP_d(self) -> float and list:
        #score, correct_id_list = self._TaP_d(self._anomalies, self._ambiguous_inst, self._prune_predictions)
        score, correct_id_list = self._TaP_d_weighted(self._anomalies, self._ambiguous_inst, self._prune_predictions, self._pi)
        return score, self._ids_2_objects(correct_id_list, self._prune_predictions)

    def _TaP_d_weighted(self, anomalies, ambiguous_inst, predictions, threshold):
        assert(len(predictions) == len(self._org_predictions_weight))

        correct_predictions = []
        total_score = decimal.Decimal(0.0)
        for prediction_id in range(len(predictions)):
            max_score = decimal.Decimal(predictions[prediction_id].get_time()[1] - predictions[prediction_id].get_time()[0] + 1)

            score = decimal.Decimal(0.0)
            for anomaly_id in range(len(anomalies)):
                anomaly = anomalies[anomaly_id]
                ambiguous = ambiguous_inst[anomaly_id]

                score += self._overlap_and_subsequent_score(anomaly, ambiguous, predictions[prediction_id])

            if (score/max_score) >= threshold:
                total_score += decimal.Decimal(1.0) * self._org_predictions_weight[prediction_id]
                correct_predictions.append(prediction_id)

        if len(predictions) == 0:
            return decimal.Decimal(0.0), []
        else:
            return total_score / decimal.Decimal(self._org_predictions_total_weight), correct_predictions

    def TaP_p(self) -> float:
        total_score = decimal.Decimal(0.0)
        prediction_id = 0
        for prediction in self._predictions:
            max_score = decimal.Decimal(prediction.get_time()[1] - prediction.get_time()[0] + 1)

            score = decimal.Decimal(0.0)
            for anomaly_id in range(len(self._anomalies)):
                anomaly = self._anomalies[anomaly_id]
                ambiguous = self._ambiguous_inst[anomaly_id]

                #score += self._overlap_and_subsequent_score(anomaly, ambiguous, prediction)
                temp_score = self._overlap_and_subsequent_score(anomaly, ambiguous, prediction)
                score += temp_score

            total_score += score/ max_score * self._org_predictions_weight[prediction_id]
            prediction_id += 1

        if len(self._predictions) == 0:
            return decimal.Decimal(0.0)
        else:
            return total_score / self._org_predictions_total_weight


import numpy as np

class eTaPR2(tapr.TaPR):
    def __init__(self, rho, pi, delta):
        super(eTaPR2, self).__init__(0.0, delta)
        self._predictions_weight = []
        self._predictions_total_weight = 0.0
        self._prune_predictions = []

        self._rho = rho
        self._pi = pi

        self._score_matrix_por = 0
        self._score_matrix_det = 0
        self._max_anomaly_score = []
        self._max_prediction_score = []

    #load data -> build the score matrix -> do pruning
    def set(self, anomalies: list, predictions: list) -> None:
        #loading data
        self.set_anomalies(anomalies)
        self.set_predictions(predictions)

        #computing weights
        for a_prediction in self._predictions:
            first, last = a_prediction.get_time()
            temp_weight = math.sqrt(last-first+1)
            self._predictions_weight.append(temp_weight)
            self._predictions_total_weight += temp_weight

        #building the score matrix
        self._score_matrix_det = np.zeros((self.get_n_anomalies(), self.get_n_predictions()))
        for anomaly_id in range(self.get_n_anomalies()):
            for prediction_id in range(self.get_n_predictions()):
                self._score_matrix_det[anomaly_id, prediction_id] = \
                    float(self._overlap_and_subsequent_score(self._anomalies[anomaly_id], self._ambiguous_inst[anomaly_id], self._predictions[prediction_id]))
        self._score_matrix_por = self._score_matrix_det.copy()

        #computing the maximum scores for each anomaly or prediction
        for an_anomaly in self._anomalies:
            start, end = an_anomaly.get_time()
            self._max_anomaly_score.append(float(self._sum_of_func(start, end, start, end, self._uniform_func)))
        for a_prediction in self._predictions:
            self._max_prediction_score.append(a_prediction.get_len())

        #pruning
        self._pruning()

    def _pruning(self):
        while True:
            tars = self._score_matrix_det.sum(axis=1)/self._max_anomaly_score
            elem_anomaly_ids = set(np.where(tars<self._rho)[0]) - set(np.where(tars==0.0)[0])
            for id in elem_anomaly_ids:
                self._score_matrix_det[id] = np.zeros(self.get_n_predictions())
            taps = self._score_matrix_det.sum(axis=0)/self._max_prediction_score
            elem_prediction_ids = set(np.where(taps<self._pi)[0]) - set(np.where(taps==0.0)[0])
            for id in elem_prediction_ids:
                self._score_matrix_det[:, id] = np.zeros(self.get_n_anomalies())

            if len(elem_anomaly_ids) == 0 and len(elem_prediction_ids) == 0:
                break

    def TaR_d(self) -> float and list:
        scores = self._score_matrix_det.sum(axis=1)/self._max_anomaly_score
        scores = np.where(scores>1.0, 1.0, scores)
        detected_id_list = np.where(scores >= self._rho)[0]
        return len(detected_id_list)/self.get_n_anomalies(), self._ids_2_objects(detected_id_list, self._anomalies)

    def TaR_p(self) -> float:
        scores = self._score_matrix_por.sum(axis=1) / self._max_anomaly_score
        scores = np.where(scores > 1.0, 1.0, scores)
        return scores.mean()

    def TaP_d(self) -> float and list:
        scores = self._score_matrix_det.sum(axis=0) / self._max_prediction_score
        correct_id_list = np.where(scores >= self._pi)[0]
        tapd = 0.0
        for correct_id in correct_id_list:
            tapd += self._predictions_weight[correct_id]
        tapd /= float(self._predictions_total_weight)
        return tapd, self._ids_2_objects(correct_id_list, self._predictions)

    def TaP_p(self) -> float:
        scores = self._score_matrix_por.sum(axis=0) / self._max_prediction_score
        final_score = 0.0
        for i in range(len(scores)):
            final_score += float(self._predictions_weight[i]) * scores[i]
        final_score /= float(self._predictions_total_weight)
        return final_score


def compute(ev: eTaPR, anomalies: list, predictions: list, alpha: float) -> dict:
    # ev = eTaPR(rho, pi, delta)
    #ev = TaPR(rho, pi, delta)

    ev.set(anomalies, predictions)
    # ev.set_anomalies(anomalies)
    # ev.set_predictions(predictions)
    #
    # ev.pruning()
    tard_value, detected_list = ev.TaR_d()
    tarp_value = ev.TaR_p()

    tapd_value, correct_list = ev.TaP_d()
    tapp_value = ev.TaP_p()

    # alpha = decimal.Decimal(alpha)

    result = {}
    tar_value = alpha * tard_value + (1 - alpha) * tarp_value
    result['TaR'] = tar_value
    result['TaRd'] = tard_value
    result['TaRp'] = tarp_value

    tap_value = alpha * tapd_value + (1 - alpha) * tapp_value
    result['TaP'] = tap_value
    result['TaPd'] = tapd_value
    result['TaPp'] = tapp_value

    detected_anomalies = []
    for value in detected_list:
        detected_anomalies.append(value.get_name())

    result['Detected_Anomalies'] = detected_anomalies
    result['Detected_Anomalies_Ranges'] = detected_list
    result['Correct_Predictions_Ranges'] = correct_list

    if tar_value + tap_value == 0:
        result['f1'] = 0.0
    else:
        result['f1'] = (2 * tar_value * tap_value) / (tar_value + tap_value)

    return result


def evaluate(anomalies: list, predictions: list) -> dict:
    # anomalous_ranges = File_IO.load_stream_2_range(anomalies, 0, 1, True)
    # predicted_ranges = File_IO.load_stream_2_range(predictions, 0, 1, True)
    ev = eTaPR2(rho=0.1, pi=0.7, delta=180)
    return compute(ev,
                   anomalies,#=anomalous_ranges,
                   predictions,#=predicted_ranges,
                   alpha=0.5)


def compute_with_load(anomaly_file: str, prediction_file: str, file_type: str, alpha: float, rho: float, pi: float, delta: int) -> dict:
    anomalies = File_IO.load_file(anomaly_file, file_type)
    predictions = File_IO.load_file(prediction_file, file_type)
    ev = eTaPR(rho, pi, delta)
    return compute(ev, anomalies, predictions, alpha)


def print_result(anomalies: list, predictions: list, alpha: float, rho: float, pi: float, delta: int, verbose: bool, graph: str) -> None:
    org_predictions = copy.deepcopy(predictions)
    ev = eTaPR(rho=rho, pi=pi, delta=delta)
    result = compute(ev, anomalies, predictions, alpha)

    print("The parameters (alpha, rho, pi, delta) are set as %g, %g, %g, and %d." % (alpha, rho, pi, delta))

    print('\n[TaR]:', "%0.5f" % result['TaR'])
    print("\t* Detection score:", "%0.5f" % result['TaRd'])
    print("\t* Portion score:", "%0.5f" % result['TaRp'])
    if verbose:
        buf = '\t\tdetected anomalies: '
        if len(result['Detected_Anomalies_Ranges']) == 0:
            buf += "None  "
        else:
            for value in result['Detected_Anomalies_Ranges']:
                buf += value.get_name() + '(' + str(value.get_time()[0]) + ':' + str(value.get_time()[1]) + '), '
        print(buf[:-2])


    print('\n[TaP]:', "%0.5f" % result['TaP'])
    print("\t* Detection score:", "%0.5f" % result['TaPd'])
    print("\t* Portion score:", "%0.5f" % result['TaPp'])
    if verbose:
        buf = '\t\tcorrect predictions: '
        if len(result['Correct_Predictions_Ranges']) == 0:
            buf += "None  "
        else:
            for value in result['Correct_Predictions_Ranges']:
                buf += value.get_name() + '(' + str(value.get_time()[0]) + ':' + str(value.get_time()[1]) + '), '
        print(buf[:-2])


    assert(graph == 'screen' or graph == 'file' or graph == 'none' or graph == 'all')
    if graph == 'screen' or graph == 'file' or graph == 'all':
        Time_Plot.draw_graphs(anomalies, org_predictions, graph)


if __name__ == '__main__':
    argument_parser = argparse.ArgumentParser()
    argument_parser.add_argument("--anomalies", help="anomaly file name (ground truth)", required=True)
    argument_parser.add_argument("--predictions", help="prediction file name", required=True)
    argument_parser.add_argument("--filetype", help="choose the file type between range and stream", required=True)
    argument_parser.add_argument("--graph", help="show graph of results")

    argument_parser.add_argument("--verbose", help="show detail results", action='store_true')
    argument_parser.add_argument("--rho", help="set parameter rho")
    argument_parser.add_argument("--pi", help="set parameter pi")
    argument_parser.add_argument("--alpha", help="set parameter alpha")
    argument_parser.add_argument("--delta", help="set parameter delta")
    arguments = argument_parser.parse_args()

    arguments = argument_parser.parse_args()
    rho, pi, alpha, delta, graph = 0.1, 0.5, 0.8, 600, 'none'  #default values
    if arguments.rho is not None:
        rho = float(arguments.rho)
    if arguments.pi is not None:
        pi = float(arguments.pi)
    if arguments.alpha is not None:
        alpha = float(arguments.alpha)
    if arguments.delta is not None:
        delta = int(arguments.delta)
    if arguments.graph is not None:
        graph = arguments.graph

    assert(0.0 <= rho <= 1.0)
    assert(0.0 <= pi <= 1.0)
    assert(0.0 <= alpha <= 1.0)
    assert(isinstance(delta, int))
    assert(graph == 'screen' or graph == 'file' or graph == 'none' or graph == 'all')

    anomalies = File_IO.load_file(arguments.anomalies, arguments.filetype)
    predictions = File_IO.load_file(arguments.predictions, arguments.filetype)

    print_result(anomalies, predictions, alpha, rho, pi, delta, arguments.verbose, graph)

